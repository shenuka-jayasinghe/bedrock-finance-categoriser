import boto3
import csv
import os
import uuid
from datetime import datetime
from urllib.parse import unquote_plus

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

# Environment Variables
TRANSACTIONS_TABLE = os.environ["TRANSACTIONS_TABLE"]
STATEMENTS_TABLE = os.environ["STATEMENTS_TABLE"]
CATEGORIES_TABLE = os.environ["CATEGORIES_TABLE"]
MONTHLY_SUMMARIES_TABLE = os.environ["MONTHLY_SUMMARIES_TABLE"]
PROCESSING_JOBS_TABLE = os.environ["PROCESSING_JOBS_TABLE"]

# DynamoDB Tables
transactions_table = dynamodb.Table(TRANSACTIONS_TABLE)
statements_table = dynamodb.Table(STATEMENTS_TABLE)
processing_jobs_table = dynamodb.Table(PROCESSING_JOBS_TABLE)

# ---- Helper functions ----

def parse_csv_from_s3(bucket, key):
    response = s3.get_object(Bucket=bucket, Key=key)
    content = response["Body"].read().decode("utf-8").splitlines()
    reader = csv.DictReader(content)
    return list(reader)

def infer_category(description):
    desc = description.lower()
    if "sport" in desc:
        return "Fitness"
    elif "manchester city" in desc:
        return "Entertainment"
    else:
        return "Uncategorized"

def process_transaction(row, user_id):
    date_str = row.get("Transaction Date")
    try:
        parsed_date = datetime.strptime(date_str, "%d/%m/%Y")
        iso_date = parsed_date.strftime("%Y-%m-%d")
    except:
        iso_date = "unknown"

    transaction_id = str(uuid.uuid4())
    description = row.get("Transaction Description", "")
    category = infer_category(description)

    debit = float(row.get("Debit Amount", 0) or 0)
    credit = float(row.get("Credit Amount", 0) or 0)
    amount = credit - debit

    return {
        "user_id": user_id,
        "transaction_id": transaction_id,
        "date": iso_date,
        "description": description,
        "amount": amount,
        "category": category,
        "user_id_category": f"{user_id}#{category}",
        "user_id_merchant": f"{user_id}#{description[:30]}"
    }

# ---- Main Lambda handler ----

def lambda_handler(event, context):
    try:
        # Only one record expected
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])

        # Assume user_id can be inferred from the filename: e.g. "user123_statement.csv"
        user_id = key.split("_")[0]

        print(f"Processing file {key} for user {user_id}")

        transactions = parse_csv_from_s3(bucket, key)
        stored_transactions = []

        for row in transactions:
            tx = process_transaction(row, user_id)
            transactions_table.put_item(Item=tx)
            stored_transactions.append(tx)

        # Optionally log job
        job_id = str(uuid.uuid4())
        processing_jobs_table.put_item(Item={
            "job_id": job_id,
            "user_id": user_id,
            "timestamp": datetime.utcnow().isoformat(),
            "record_count": len(stored_transactions),
            "status": "COMPLETED",
            "source_file": key
        })

        return {
            "statusCode": 200,
            "body": f"Processed {len(stored_transactions)} transactions for user {user_id}"
        }

    except Exception as e:
        print(f"Error processing file: {e}")
        raise
